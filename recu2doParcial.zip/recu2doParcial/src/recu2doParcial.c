/*
 ============================================================================
 Name        : recu2doParcial.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct
{
	int id;
	char nombre[20];
	char tipo[20];
	int edad;
	float altura;
}eMascota;

eMascota* mascota_new();
eMascota* mascota_nuevoParametros(int id,char* nombre,char* tipo, int edad, float altura);
int mascotaSetNombre(eMascota* this,char* nombre);
int mascotaSetTipo(eMascota* this,char* tipo);
int mascotaSetId(eMascota* this,int id);
int mascotaSetEdad(eMascota* this,int edad);
int mascotaSetAltura(eMascota* this,float altura);
int guardarEnTexto(char* path, eMascota* mascota);
int guardarEnBinario(char* path, eMascota* mascota);


int main(void) {

	 eMascota* mascotas = mascota_nuevoParametros(1215, "Bobby", "Perro", 5, 25.15);
	    printf("%d\n", mascotas->id);
	    printf("%s\n", mascotas->nombre);
	    printf("%s\n", mascotas->tipo);
	    printf("%d\n", mascotas->edad);
	    printf("%.2f\n", mascotas->altura);

	    guardarEnTexto("Mascota", mascotas);
	    guardarEnBinario("MascotaBin", mascotas);

	return EXIT_SUCCESS;
}
eMascota* mascota_new()
{
	eMascota* p =(eMascota*) malloc(sizeof(eMascota));
    if(p!= NULL)
    {
        p->id=0;
        strcpy(p->nombre, " ");
        strcpy(p->tipo, " ");
        p->edad=0;
        p->altura=0;

    }
    return p;
}

eMascota* mascota_nuevoParametros(int id,char* nombre,char* tipo, int edad, float altura)
{
	eMascota* p = mascota_new();
    if(p!= NULL)
    {
        if(!(mascotaSetId(p, id)==0 && mascotaSetNombre(p, nombre)==0 && mascotaSetTipo(p, tipo)== 0 && mascotaSetEdad(p, edad)==0 && mascotaSetAltura(p, altura)==0))
        {
            p = NULL;
        }
    }
    return p;
}

///////////////////////////////////////////////////////////////////////////SETTERS///////////////////////////////////////////////////////////////////////////

int mascotaSetNombre(eMascota* this,char* nombre)
{
    int todoOk=1;
    if(this!=NULL && nombre!=NULL && strlen(nombre)<20)
    {
        strcpy(this->nombre, nombre);
        todoOk=0;
    }

    return todoOk;
}
int mascotaSetTipo(eMascota* this,char* tipo)
{
    int todoOk=1;
    if(this!=NULL && tipo!=NULL && strlen(tipo)<20)
    {
        strcpy(this->tipo, tipo);
        todoOk=0;
    }

    return todoOk;
}
int mascotaSetId(eMascota* this,int id)
{
    int todoOk=1;
    if(this!=NULL && id >0)
    {
        this->id=id;
        todoOk=0;
    }

    return todoOk;
}

int mascotaSetEdad(eMascota* this,int edad)
{
    int todoOk=1;
    if(this!=NULL && edad >0)
    {
        this->edad=edad;
        todoOk=0;
    }

    return todoOk;
}


int mascotaSetAltura(eMascota* this,float altura)
{
    int todoOk=1;
    if(this!=NULL && altura >0)
    {
        this->altura=altura;
        todoOk=0;
    }

    return todoOk;
}
int guardarEnTexto(char* path, eMascota* mascota)
{
    int retorno=0;
    FILE* f = NULL;
    f = fopen(path, "w");
    if(f!= NULL && mascota != NULL)
    {
        int cant = fprintf(f, "%d,%s,%s,%d,%f", mascota->id, mascota->nombre,mascota->tipo,mascota->edad, mascota->altura);
        if(cant <=0)
        {
            printf("Ocurrio algo\n");
        }
        retorno=1;
    }
    fclose(f);
    return retorno;
}

int guardarEnBinario(char* path, eMascota* mascota)
{
    int retorno=0;
    FILE* f = NULL;
    f = fopen(path, "wb");
    if(f!= NULL && mascota != NULL)
    {
        if(fwrite(mascota, sizeof(eMascota), 1, f) != 1)
        {
            printf("Hubo un error\n");
        }
        retorno=1;
    }
    return retorno;
    fclose(f);
}
