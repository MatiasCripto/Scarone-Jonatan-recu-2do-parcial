

#include "parser.h"
#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"


#include "posts.h"

int parser_cargarDesdeTexto(FILE *pFile, LinkedList *pArrayList)
{
	int todoOk = 0;

	char buffer[5][150];
	Posts *pPosts;

	if (pFile != NULL && pArrayList != NULL)
	{

		fscanf(pFile, "%[^,],%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1],
				buffer[2], buffer[3], buffer[4]);

		do {

			if (fscanf(pFile, "%[^,],%[^,],%[^,],%[^,],%[^\n]\n", buffer[0],
					buffer[1], buffer[2], buffer[3], buffer[4]) < 5)
			{
				break;
			}
			else
			{
				pPosts = pos_newParametros(buffer[0], buffer[1], buffer[2],
						buffer[3], buffer[4]);
				if (pPosts == NULL)
				{
					break;
				}
				else
				{
					ll_add(pArrayList, (Posts*) pPosts);
					todoOk = 1;
				}
			}
		} while (feof(pFile) == 0);
	}

	return todoOk;
}
