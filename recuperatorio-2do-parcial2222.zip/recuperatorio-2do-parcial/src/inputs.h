/*
 * inputs.h
 *
 *  Created on: 1 dic. 2022
 *      Author: Pablo
 */

#ifndef INPUTS_H_
#define INPUTS_H_
int myGets(char* cadena, int longitud);
int getInt(int* pResultado);
int esNumerica(char* cadena);
int utn_getNumero(int* pResultado, char* mensaje,
		char* mensajeError, int minimo, int maximo, int reintentos);
int isValidNombre(char *pBuffer, int limite);
int utn_getNombre( char *pNombre, int limite, char *mensaje, char *mensajeError, int reintentos);
int getString(char *pBuffer, int limite);


#endif /* INPUTS_H_ */
