

#include "posts.h"
#include <stdio.h>
#include <stdlib.h>

Posts* pos_new()
{
	Posts* pPosts = (Posts*) malloc(sizeof(Posts));

	return pPosts;
}

Posts* pos_newParametros(char *idStr, char *userStr, char *likesStr,
		char *dislikesStr, char *followersStr)
{

	Posts* pPosts = pos_new();

	if (pPosts != NULL && idStr != NULL && userStr != NULL
			&& likesStr != NULL && dislikesStr != NULL && followersStr != NULL)
	{
		if (!(pos_setId(pPosts, atoi(idStr))
				&& pos_setUser(pPosts, userStr)
				&& pos_setLikes(pPosts, atoi(likesStr))
				&& pos_setDislikes(pPosts, atoi(dislikesStr)
				)&& pos_setFollowers(pPosts, atoi(followersStr))))
		{
			free(pPosts);
			pPosts = NULL;
		}
	}
	else
	{
		puts("\nOcurrio un error.");
	}

	return pPosts;
}
void pos_delete(Posts *this)
{
	free(this);
}

int pos_getId(Posts *this, int *id)
{
	int todoOk = 0;
	if (this != NULL && id != NULL)
	{
		*id = this->id;
		todoOk = 1;
	}
	return todoOk;
}
int pos_getUser(Posts *this, char *user)
{
	int todoOk = 0;
	if (this != NULL && user != NULL)
	{
		strcpy(user, this->user);
		todoOk = 1;
	}
	return todoOk;
}


int pos_getLikes(Posts *this, int *likes)
{
	int todoOk = 0;
	if (this != NULL && likes != NULL)
	{
		*likes = this->likes;
		todoOk = 1;
	}
	return todoOk;
}

int pos_getDisLikes(Posts *this, int *dislikes)
{
	int todoOk = 0;
		if (this != NULL && dislikes != NULL)
		{
			*dislikes = this->dislikes;
			todoOk = 1;
		}
		return todoOk;
}
int pos_getFollowers(Posts *this, int *followers)
{
	int todoOk = 0;
	if (this != NULL && followers != NULL)
	{
		*followers = this->followers;
		todoOk = 1;
	}
	return todoOk;
}


int pos_setId(Posts *this, int id)
{
	int todoOk = 0;

		if (this != NULL)
		{
			this->id = id;
			todoOk = 1;
		}

		return todoOk;
}

int pos_setUser(Posts *this, char* user)
{
	int todoOk = 0;

	if (this != NULL && user != NULL )
	{
		strcpy(this->user, user);
		todoOk = 1;
	}
	else
	{
		puts("\nUSER INVALIDO.");
	}

	return todoOk;
}

int pos_setLikes(Posts *this, int likes)
{
	int todoOk = 0;

		if (this != NULL)
		{
			this->likes = likes;
			todoOk = 1;
		}

		return todoOk;
}

int pos_setDislikes(Posts *this, int dislikes)
{
	int todoOk = 0;

		if (this != NULL)
		{
			this->dislikes = dislikes;
			todoOk = 1;
		}

		return todoOk;
}
int pos_setFollowers(Posts *this, int followers)
{
	int todoOk = 0;

		if (this != NULL)
		{
			this->followers = followers;
			todoOk = 1;
		}

		return todoOk;
}
void funcMapLikes(void *this)
{
	Posts *posts;
	int min = 600;
	int max = 5000;
	int numeroRandom;
	if (this != NULL)
	{
		posts = (Posts*) this;
		numeroRandom = rand() % (max - min + 1) + min;
		pos_setLikes(posts, numeroRandom);
	}
}
void funcMapDislikes(void *this)
{
	Posts *posts;
	int min = 300;
	int max = 3500;
	int numeroRandom;
	if (this != NULL)
	{
		posts = (Posts*) this;
		numeroRandom = rand() % (max - min + 1) + min;
		pos_setDislikes(posts, numeroRandom);
	}
}
void funcMapFollowers(void *this)
{
	Posts *posts;
	int min = 10000;
	int max = 20000;
	int numeroRandom;
	if (this != NULL)
	{
		posts = (Posts*) this;
		numeroRandom = rand() % (max - min + 1) + min;
		pos_setFollowers(posts, numeroRandom);
	}
}
int pos_mostrarPost( Posts* post)
{
	int todoOk = 0;
	int id;
	char user[50];
	int likes;
	int dislikes;
	int followers;


	if(pos_getId(post, &id)&&
	   pos_getUser(post, user)&&
	   pos_getLikes(post, &likes)&&
	   pos_getDisLikes(post, &dislikes)&&
	   pos_getFollowers(post, &followers))
	{
		printf("-----------------------------------------------------------------------------------------------\n");
		printf("|  %4d  |%-15s|%3d  |%6d|%6d|\n",id,user,likes,dislikes,followers);
		todoOk = 1;
	}

	return todoOk;
}
int pFuncLikes(void* pElemento)
{
	int todoOk = 0;
	Posts* auxPosts;
	int likes;
	if(pElemento != NULL)
	{
		auxPosts = (Posts*) pElemento;
		pos_getLikes(pElemento, &likes);
		if(likes > 4000)
		{
			todoOk = 1;
		}
	}
	return todoOk;
}
int pFuncHeaters(void* pElemento)
{
	int todoOk = 0;
	Posts* auxPosts;
	int dislikes;
	int likes;
	if(pElemento != NULL)
	{
		auxPosts = (Posts*) pElemento;
		pos_getDisLikes(pElemento, &dislikes);
		pos_getLikes(pElemento, &likes);
		if(dislikes > likes)
		{
			todoOk = 1;
		}
	}
	return todoOk;
}
int ordenarPorFollowers(void *pPrimerPosts, void *pSegundoPosts)
{
	int todoOk = 0;
	Posts *auxPrimerPosts;
	Posts *auxSegundoPosts;
	int followerPrimerPosts;
	int followerSegundoPosts;
	int resultadoOrdenamientoFollower;

	if (pPrimerPosts != NULL && pSegundoPosts != NULL)
	{
		auxPrimerPosts = (Posts*) pPrimerPosts;
		auxSegundoPosts = (Posts*) pSegundoPosts;
		if (pos_getFollowers(auxPrimerPosts, &followerPrimerPosts)
			&& pos_getFollowers(auxSegundoPosts, &followerSegundoPosts))
		{
			resultadoOrdenamientoFollower = followerPrimerPosts
					> followerSegundoPosts;

			if (resultadoOrdenamientoFollower)
			{
				todoOk = 1;
			}
			else
			{
				todoOk = -1;
			}

		}
	}

	return todoOk;
}


