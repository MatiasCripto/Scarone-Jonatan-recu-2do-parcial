/*
 * eMovies.h
 *
 *  Created on: 25 Nov 2022
 *      Author: Julian
 */

#ifndef eMovieS_H_
#define eMovieS_H_
#define TITULO_CHARS 50

#include <string.h>

typedef struct {
	int id;
	char user[50];
	int likes;
	int dislikes;
	int followers;
} Posts;

/// \brief Constructor por defecto de posts
///
/// \return retorna puntero a posts
Posts* pos_new();

/// \brief Constructor por parametros de posts
///
/// \param idStr id en forma de char
/// \param tituloStr titulo en forma de char
/// \param generoStr genero en forma de char
/// \param ratingStr rating en forma de char
/// \return
Posts* pos_newParametros(char *idStr, char *userStr, char *likesStr,
		char *dislikesStr, char *followersStr);

/// \brief Destructor de posts
///
/// \param this Puntero a posts
void pos_delete(Posts *this);

/// \brief Getter de id
///
/// \param this Puntero a posts
/// \param id variable que almacena id
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_getId(Posts *this, int *id);

/// \brief Getter de user
///
/// \param this Puntero a posts
/// \param titulo variable que almacena user
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_getUser(Posts *this, char *user);

/// \brief Getter de likes
///
/// \param this Puntero a posts
/// \param genero variable que almacena likes
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_getLikes(Posts *this, int *likes);

/// \brief Getter de dislikes
///
/// \param this Puntero a posts
/// \param rating variable que almacena dislikes
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_getDisLikes(Posts *this, int *dislikes);

/// \brief Getter de rating
///
/// \param this Puntero a posts
/// \param rating variable que almacena rating
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_getFollowers(Posts *this, int *followers);
/// \brief Setter de titulo
///
/// \param this puntero a posts
/// \param titulo valor de titulo a cargar
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_setUser(Posts *this, char* user);

/// \brief Setter de id
///
/// \param this puntero a posts
/// \param id valor de id a cargar
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_setId(Posts *this, int id);

/// \brief Setter de rating
///
/// \param this puntero a posts
/// \param rating valor de rating a cargar
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_setLikes(Posts *this, int likes);

/// \brief Setter de genero
///
/// \param this puntero a posts
/// \param genero valor de genero a cargar
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_setDislikes(Posts *this, int dislikes);

/// \brief Setter de genero
///
/// \param this puntero a posts
/// \param genero valor de genero a cargar
/// \return retorna 1 en caso de exito y 0 en caso de error
int pos_setFollowers(Posts *this, int followers);

void funcMapDislikes(void *this);

void funcMapFollowers(void *this);

void funcMapLikes(void *this);

int pos_mostrarPost( Posts* post);

int pFuncLikes(void* pElemento);

int pFuncHeaters(void* pElemento);

int ordenarPorFollowers(void *pPrimerPosts, void *pSegundoPosts);

#endif /* eMovieS_H_ */
