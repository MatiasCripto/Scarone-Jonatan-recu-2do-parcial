

#include "controller.h"
#include <stdio.h>
#include <stdlib.h>
#include "parser.h"
#include "posts.h"


int controller_cargarDesdeTexto(char *path, LinkedList *pArrayList)
{
	int todoOk = 0;

	FILE *pFile = fopen(path, "r");

	if (path != NULL && pArrayList != NULL)
	{
		if (pFile == NULL)
		{
			puts("\nERROR. No es posible abrir el archivo");
		}
		else
		{
			if (ll_isEmpty(pArrayList))
			{
				if (parser_cargarDesdeTexto(pFile, pArrayList))
				{
					printf("\nArchivo cargado con exito\n");
					todoOk = 1;
				}
				else
				{
					puts("\nERROR. Ocurrio un error al cargar el archivo\n");
				}
			}
			else
			{
				todoOk = -1;
				puts("\nLa lista no esta vacia.\n");
			}
		}
	}

	fclose(pFile);
	return todoOk;
}

int controller_listarPosts(LinkedList *this)
{
	int todoOk = 0;
	int i;
	int arrayTam;
	Posts* pPosts;

	if (this != NULL)
	{
		arrayTam = ll_len(this);
		if (arrayTam != -1)
		{
			puts("\n=====================================================================");
			printf("    ID       USER       LIKES         DISLIKES         FOLLOWERS    \n");
			puts("=======================================================================");

			for (i = 0; i < arrayTam; i++)
			{
				pPosts = (Posts*) ll_get(this, i);
				if(pPosts != NULL)
				{
					pos_mostrarPost(pPosts);
				}

			}
			todoOk = 1;
			}
		}
	return todoOk;
}

int controller_asignarLikes(LinkedList *this)
{
	int todoOk = 0;
	void (*pFunc)(void *element);

	if (this != NULL)
	{
		pFunc = funcMapLikes;
		this = ll_map(this, pFunc);
		todoOk = 1;
	}

	controller_listarPosts(this);

	return todoOk;
}
int controller_asignarDislikes(LinkedList *this)
{
	int todoOk = 0;
	void (*pFunc)(void *element);

	if (this != NULL)
	{
		pFunc = funcMapDislikes;
		this = ll_map(this, pFunc);
		todoOk = 1;
	}

	controller_listarPosts(this);

	return todoOk;
}
int controller_asignarFollowers(LinkedList *this)
{
	int todoOk = 0;
	void (*pFunc)(void *element);

	if (this != NULL)
	{
		pFunc = funcMapFollowers;
		this = ll_map(this, pFunc);
		todoOk = 1;
	}

	controller_listarPosts(this);

	return todoOk;
}

int controller_guardarPostsModoTexto(char *path, LinkedList *pArrayList)
{
	int todoOk = 0;
	FILE *pFile;
	int tamArray;
	int i;
	Posts auxPosts;
	Posts *pPosts = NULL;
	if (path != NULL && pArrayList != NULL)
	{
		pFile = fopen(path, "w");
		if (pFile != NULL) {
			fprintf(pFile, "id,user,likes,dislikes,followers\n");
			tamArray = ll_len(pArrayList);
			for (i = 0; i < tamArray; i++)
			{
				pPosts = (Posts*) ll_get(pArrayList, i);
				if (pPosts != NULL)
				{
					if (!(pos_getId(pPosts, &auxPosts.id)
							&& pos_getUser(pPosts, auxPosts.user)
							&& pos_getLikes(pPosts, &auxPosts.likes)
							&& pos_getDisLikes(pPosts, &auxPosts.dislikes)
							&& pos_getFollowers(pPosts, &auxPosts.followers)))
					{
						pPosts = NULL;
						pos_delete(pPosts);
						printf(
								"\nOcurrio un error el guardar daots en el archivo");
						break;
					} else {
						fprintf(pFile, "%d,%s,%d,%d,%d\n", auxPosts.id,
								auxPosts.user, auxPosts.likes,
								auxPosts.dislikes,auxPosts.followers);
						todoOk = 1;
					}
				}
			}
		}
	}
	fclose(pFile);
	return todoOk;
}

int controller_listaFiltradaPorLikes(LinkedList *this,	char *path)
{
	int todoOk = 0;
	LinkedList *listaFiltrada = ll_newLinkedList();
	int (*pFunc)(void*);

	if (this != NULL)
	{
		pFunc = pFuncLikes;

		listaFiltrada = ll_filter(this, pFunc);
	}

	if (controller_guardarPostsModoTexto(path, listaFiltrada))
	{
		todoOk = 1;
	}

	return todoOk;
}
int controller_listaFiltradaHeaters(LinkedList *this,	char *path)
{
	int todoOk = 0;
	LinkedList *listaFiltrada = ll_newLinkedList();
	int (*pFunc)(void*);

	if (this != NULL)
	{
		pFunc = pFuncHeaters;

		listaFiltrada = ll_filter(this, pFunc);
	}

	if (controller_guardarPostsModoTexto(path, listaFiltrada))
	{
		todoOk = 1;
	}

	return todoOk;
}

int controller_ordenarPosts(LinkedList *this)
{
	int todoOk = 0;
	int (*pFunc)(void*, void*);

	if (this != NULL)
	{
		pFunc = ordenarPorFollowers;
		ll_sort(this, pFunc, 0);
		todoOk = 1;
	}
	return todoOk;
}
int controller_encontrarMayor(LinkedList *this)
{
	int todoOk = 0;
	Posts* auxPosts;
	int auxLikes;
	Posts* postMasLikes = NULL;
	int mayorCantidadLikes;
	int i;
	if(this != NULL)
	{
		for(i = 0; i <ll_len(this); i++)
		{
			auxPosts = (Posts*) ll_get(this,i);
			auxLikes = pos_getLikes(auxPosts, &auxLikes);

			if(i == 0 || auxLikes > mayorCantidadLikes)
			{
				mayorCantidadLikes = auxLikes;
				postMasLikes = auxPosts;
			}
		}
		todoOk = 1;
		printf("El user  con mas likes es: %s con %d ", postMasLikes->user, postMasLikes->likes);
	}
	return todoOk;

}

