/*
 ============================================================================
 Name        : recuperatorio-2do-parcial.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "menu.h"
#include "inputs.h"
#include "controller.h"
#include "time.h"

int main(void) {
	setbuf(stdout, NULL);
	srand(time(NULL));
	char seguir = 'n';
	LinkedList *listaPosts = ll_newLinkedList();
	char archivo[50];
	char archivoGuardar[50];



	do {

		switch (menuPrincipal()) {
		case 1:

			if (utn_getNombre(archivo,50,"\nIngrese el nombre del archivo: ",
					"\nNombre invalido. ", 30 ) == 0) {
				strcat(archivo, ".csv");
				controller_cargarDesdeTexto(archivo, listaPosts);
			}
			break;
		case 2:
			if (!ll_isEmpty(listaPosts)) {
				controller_listarPosts(listaPosts);
			} else {
				puts("\n la lista esta vacia");
			}
			break;
		case 3:
			if (!ll_isEmpty(listaPosts)) {
				if (controller_asignarLikes(listaPosts) &&
						controller_asignarDislikes(listaPosts) &&
						controller_asignarFollowers(listaPosts)) {
					puts("\nLikes asignado con exito");
				}
			}
			else
			{
				puts("\n la lista esta vacia");
			}
			break;
		case 4:
			if (!ll_isEmpty(listaPosts))
			  {
				if (utn_getNombre(archivoGuardar,50,
						"\nIngrese el nombre del archivo a guardar: ",
						"\nNombre invalido.",30 )
						== 0) {
					strcat(archivoGuardar, ".csv");
					if (controller_listaFiltradaPorLikes(listaPosts,
							 archivoGuardar))
					{
						puts("\nLista creada y filtrada con exito");

					}
				}
			}

			break;
		case 5:
			if(!ll_isEmpty(listaPosts))
			  {
				if (utn_getNombre(archivoGuardar,50,
						"\nIngrese el nombre del archivo a guardar: ",
						"\nNombre invalido.",30 )
						== 0) {
					strcat(archivoGuardar, ".csv");
					if (controller_listaFiltradaHeaters(listaPosts,
							 archivoGuardar))
					{
						puts("\nLista creada y filtrada con exito");

					}
				}
			}
			break;
		case 6:
			if (!ll_isEmpty(listaPosts)) {
				if (controller_ordenarPosts(listaPosts)) {
					puts("\nPosts ordenadas con exito");
				}
				controller_listarPosts(listaPosts);
			}
			break;
		case 7:
			controller_encontrarMayor(listaPosts);
			break;
		case 8:
			break;
		}

	} while ( seguir == 'n');

	return EXIT_SUCCESS;
}
