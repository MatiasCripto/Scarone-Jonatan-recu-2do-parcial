#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "inputs.h"


/** \brief
 *
 * \param cadena char* cadena a recorrer
 * \param longitud int longitud de la cadena
 * \return int -1 Error: NO es numerica. 0 Es valido
 *
 */
int myGets(char* cadena, int longitud)
{
    if(cadena != NULL && longitud >0 && fgets(cadena, longitud, stdin)==cadena)
    {
        fflush(stdin);
        if(cadena[strlen(cadena)-1] == '\n')
        {
            cadena[strlen(cadena)-1] = '\0';
        }
        return 0;
    }
    return -1;

}
/** \brief Obtiene el dato como una cadena de caracteres, para luego
 * 	      validarlo y parsear/formatear el dato a una variable entera.
 *
 * \param pResultado int* Puntero a entero, con el valor a setear.
 * \return int retorna -1 si la validacion fallo y 0 si salio bien
 *
 */
int getInt(int* pResultado)
{
    int todoOk = -1;
    char buffer[64];

    if(pResultado != NULL)
    {
        if(myGets(buffer, sizeof(buffer))==0 && esNumerica(buffer))
        {
            *pResultado = atoi(buffer);
            todoOk = 0;
        }

    }
    return todoOk;
}

/** \brief Recibe una cadena de caracteres y devuelve 1
 * 		  en el caso de que el texto este compuesto solo por n�meros.
 *
 * \param cadena char* Cadena de carateres a recorrer.
 * \return int retorna 1 si la validacion fallo y 0 si salio todo bien
 *
 */
int esNumerica(char* cadena)
{
    int i=0;
    int todoOk = 1;
    if(cadena != NULL && strlen(cadena) < 0)
    {
        while(cadena[i] != '\0')
        {
            if(cadena[i] <'0' || cadena[i] > '9'/* || cadena[i] != ','*/)// para flotante, contar las comas y que me ermita una sola
            {
            	todoOk =0;
                break;
            }
            i++;
        }
    }
    return todoOk;
}

/** \brief Pide al usuario un numero
 *
 * \param pResultado int* Direccion de memoria de la variable donde escribe el valor ingresado por el usuario
 * \param mensaje char* El mensaje que imprime para pedir un valor
 * \param mensajeError char* mensaje que imprime si el rango no es valido
 * \param minimo int valor minimo valido (inclusive)
 * \param maximo int valor maximo valido (no inclusive)
 * \param reintentos int cantidad de reintentos
 * \return int retorna 0  si esta todo OK. -1: Si hubo un error
 *
 */
int utn_getNumero(int* pResultado, char* mensaje, char* mensajeError, int minimo, int maximo, int reintentos)
{
    int bufferInt;
    int todoOk = -1;
    while(reintentos>0)
    {
        reintentos--;
        printf("%s", mensaje);
        if(getInt(&bufferInt)==0)
        {
            if(bufferInt >= minimo && bufferInt <= maximo)
            {
                *pResultado = bufferInt;
                todoOk = 0;
                break;
            }
        }
        printf("%s", mensajeError);
    }
    return todoOk;
}
/** \brief valida una cadena de caracteres
 *
 * \param pBuffer char* puntero a guardar el dato
 * \param limite int limite de la cadena
 * \return int retorna 0 si fallo y 1 si salio todo bien
 *
 */
int isValidNombre(char *pBuffer, int limite)
{
    int todoOk = 0;
    if( pBuffer != NULL && limite > 0 && strlen(pBuffer) > 0 &&
            ((pBuffer[0]>='A' && pBuffer[0]<='Z') || (pBuffer[0]>='a' && pBuffer[0]<='z')))
    {
    	todoOk = 1;
    }
    return todoOk;
}

/** \brief valida que sea una cadena
 *
 * \param pBuffer char* puntero a guardar el dato
 * \param limite int limite de la cadena
 * \return int  retorna -1 si fallo, y 0 si salio todo bien
 *
 */
int getString(char *pBuffer, int limite)
{
    int todoOk = -1;
    int len;
    char bufferString[4096];
    if(pBuffer != NULL && limite > 0 )
    {
        fflush(stdin);
        fgets(bufferString, 4096, stdin);
        len = strlen(bufferString);
        if(len <= limite)
        {
            if(len != limite-1 || bufferString[limite-2] == '\n')
            {
                bufferString[len-1] = '\0';
            }
            strncpy(pBuffer, bufferString, limite);
            todoOk = 0;
        }
        else
        {
            printf("Se admite un maximo de %d caracteres\n", limite - 1);
        }
    }
    return todoOk;
}
/** \brief pide una cadena al usuario y la valida
 *
 * \param pNombre char* cadena a recibir
 * \param limite int limite de caracteres de la cadena
 * \param mensaje char* mensaje de peticion al usuario
 * \param mensajeError char* mensaje de error
 * \param reintentos int cantidad de reintentos
 * \return int retorna -1 si fallo, y 0 si salio todo bien
 *
 */
int utn_getNombre(  char *pNombre, int limite, char *mensaje, char *mensajeError, int reintentos)
{
    int todoOk=-1;
    char buffer[4096];
    if( pNombre != NULL && limite > 0 && mensaje != NULL &&
            mensajeError != NULL && reintentos>=0)
    {
        do
        {
            reintentos--;
            printf("\n%s", mensaje);
            if(getString(buffer, limite) == 0 &&
                    isValidNombre(buffer, limite))
            {
                strncpy(pNombre, buffer, limite);
                todoOk = 0;
                break;
            }
            else
            {
                printf("\n%s", mensajeError);
            }
        }
        while(reintentos>=0);
    }
    return todoOk;
}
