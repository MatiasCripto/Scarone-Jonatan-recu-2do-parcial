#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "menu.h"
#include "inputs.h"


int menuPrincipal()
{
    int opcion;
    system("cls");
    printf("     *** MENU PRINCIPAL ***     \n\n");
    printf(" 1- CARGAR ARCHIVO\n");
    printf(" 2- IMPRIMIR LISTA\n");
    printf(" 3- ASIGNAR ESTADISTICAS\n");
    printf(" 4- FILTRAR POR MEJORES POSTEOS\n");
    printf(" 5- FILTRAR POR HATERS\n");
    printf(" 6- ORDENAR POR FOLLOWERS\n");
    printf(" 7- MOSTRAR MAS POPULAR\n");
    printf(" 8- SALIR\n");

    if((utn_getNumero(&opcion, "Ingrese una opcion\n","Error, opcion invalida, reingrese una opcion\n",1,8,99)) == -1)
    {
    	exit(1);
    }
    return opcion;
}

int confirmarSalida(char* pSalida)
{
    int todoOk;
    char confirma;

    todoOk = 0;

    if(pSalida != NULL)
    {
        printf("confirma salida? presione S si quiere salir: \n");
        fflush(stdin);
        confirma = tolower (getchar());
        if(confirma == 's')
        {
            *pSalida = 's';
        }

        todoOk = 1;
    }
    return todoOk;
}
