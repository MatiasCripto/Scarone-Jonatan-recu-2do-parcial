/*
 * menu.h
 *
 *  Created on: 1 dic. 2022
 *      Author: Pablo
 */

#ifndef MENU_H_
#define MENU_H_
int menuPrincipal();
int confirmarSalida(char* pSalida);

#endif /* MENU_H_ */
